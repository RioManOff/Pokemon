POGO PRO MENU — Projet Android de départ

Contenu :
- Application Android indépendante.
- Calculateur IV manuel (attaque, défense, PV : 0 à 15).
- Bouton flottant activable avec l'autorisation Android « Afficher par-dessus les autres applis ».

Limites :
- Ce projet ne modifie pas Pokémon GO.
- Pas d'injection, de faux GPS, de téléportation dans le jeu, d'auto-catch ou de contournement anti-triche.
- Le gestionnaire Pokémon est une page de démonstration pour cette première version.

Compilation :
1. Installe Android Studio sur un ordinateur.
2. Ouvre le dossier POGO_PRO_MENU.
3. Laisse Gradle synchroniser le projet.
4. Choisis Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Récupère l'APK dans app/build/outputs/apk/debug/.

Configuration : compileSdk 35, minSdk 26 (Android 8.0+).
