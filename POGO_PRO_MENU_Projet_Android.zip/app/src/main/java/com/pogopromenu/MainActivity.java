package com.pogopromenu;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int red = 0xFFFF2525;
    LinearLayout root;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setBackgroundColor(0xFF101010);

        TextView title = new TextView(this);
        title.setText("POGO PRO MENU");
        title.setTextColor(red);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 12, 0, 24);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Outil compagnon Pokémon GO");
        subtitle.setTextColor(0xFFFFFFFF);
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        addButton("Calculateur IV", v -> showIvCalculator());
        addButton("Gestionnaire Pokémon", v -> showManager());
        addButton("Activer le bouton flottant", v -> enableOverlay());
        addButton("À propos / sécurité", v -> new AlertDialog.Builder(this)
            .setTitle("POGO PRO MENU")
            .setMessage("Application compagnon indépendante. Elle ne modifie pas Pokémon GO, n'injecte aucun code et ne réalise pas d'actions automatiques dans le jeu.")
            .setPositiveButton("OK", null).show());

        setContentView(root);
    }

    void addButton(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFB71919));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = 16;
        root.addView(b, p);
        b.setOnClickListener(listener);
    }

    void showIvCalculator() {
        LinearLayout box = new LinearLayout(this);
        box.setPadding(12, 8, 12, 8);
        box.setOrientation(LinearLayout.VERTICAL);
        EditText atk = field("Attaque (0 à 15)");
        EditText def = field("Défense (0 à 15)");
        EditText hp = field("PV (0 à 15)");
        box.addView(atk); box.addView(def); box.addView(hp);
        new AlertDialog.Builder(this).setTitle("Calculateur IV")
            .setView(box)
            .setPositiveButton("Calculer", (d, w) -> {
                try {
                    int a = valid(atk), de = valid(def), h = valid(hp);
                    double pct = (a + de + h) / 45.0 * 100.0;
                    new AlertDialog.Builder(this).setTitle("Résultat IV")
                        .setMessage(String.format(java.util.Locale.FRANCE, "%.1f %% (%d/45)", pct, a+de+h))
                        .setPositiveButton("OK", null).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Entre trois valeurs de 0 à 15.", Toast.LENGTH_LONG).show();
                }
            }).setNegativeButton("Annuler", null).show();
    }

    EditText field(String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setInputType(2); e.setHint(hint);
        return e;
    }
    int valid(EditText e) {
        int n = Integer.parseInt(e.getText().toString());
        if (n < 0 || n > 15) throw new IllegalArgumentException();
        return n;
    }

    void showManager() {
        new AlertDialog.Builder(this).setTitle("Gestionnaire Pokémon")
            .setMessage("Version 1 : note ici tes Pokémon et leurs IV. Le stockage local sera ajouté dans une prochaine version.")
            .setPositiveButton("OK", null).show();
    }

    void enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } else {
            startService(new Intent(this, FloatingMenuService.class));
            Toast.makeText(this, "Bouton flottant activé", Toast.LENGTH_SHORT).show();
        }
    }
}
