package com.pogopromenu;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

public class FloatingMenuService extends Service {
    private WindowManager wm;
    private Button bubble;
    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        bubble = new Button(this);
        bubble.setText("POGO");
        bubble.setTextColor(0xFFFFFFFF);
        bubble.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFE51B23));
        int type = android.os.Build.VERSION.SDK_INT >= 26 ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
            WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.END;
        p.x = 24; p.y = 220;
        wm.addView(bubble, p);
        bubble.setOnClickListener(v -> Toast.makeText(this,
            "POGO PRO MENU : ouvre l'application pour les outils IV.", Toast.LENGTH_SHORT).show());
        bubble.setOnLongClickListener(v -> { stopSelf(); return true; });
    }
    @Override public void onDestroy() {
        if (bubble != null) wm.removeView(bubble);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
